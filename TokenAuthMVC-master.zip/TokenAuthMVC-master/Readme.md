﻿Token-Based Authentication for Web Service APIs in C# MVC .NET
--------

A C# .NET MVC 5 example of implementing token-based authentication for an MVC controller.

See tutorial:
http://www.primaryobjects.com/CMS/Article165

License
----

MIT

Author
----
Kory Becker
http://www.primaryobjects.com/kory-becker
